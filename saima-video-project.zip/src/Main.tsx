import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { Footage, Grade } from "./components/Footage";
import { Captions } from "./components/Captions";
import { S, f } from "./timing";
import * as G from "./scenes/Scenes";

// সিন বসানো: সময় আসে timing.ts-এর S থেকে, তাই graphicWindows-এর সাথে হুবহু মেলে
const Seq: React.FC<{ k: keyof typeof S; pad?: number; children: React.ReactNode }> = ({ k, pad = 0, children }) => (
  <Sequence from={f(S[k][0])} durationInFrames={f(S[k][1]) - f(S[k][0]) + pad} layout="none">
    {children}
  </Sequence>
);

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Footage />
    <Grade />
    <Sequence from={0} durationInFrames={f(2.4)} layout="none"><G.IntroBrackets /></Sequence>
    <Seq k="greet"><G.Greeting /></Seq>
    <Seq k="third"><G.LowerThird /></Seq>
    <Seq k="welcome"><G.Welcome /></Seq>
    <Seq k="collection"><G.Collection /></Seq>
    <Seq k="rating"><G.Rating /></Seq>
    <Seq k="spot"><G.Spotlight /></Seq>
    <Seq k="price"><G.PriceScene /></Seq>
    <Seq k="contacts"><G.Contacts /></Seq>
    <Seq k="location"><G.Location /></Seq>
    <Seq k="closing" pad={60}><G.Closing /></Seq>
    <Captions />
  </AbsoluteFill>
);
