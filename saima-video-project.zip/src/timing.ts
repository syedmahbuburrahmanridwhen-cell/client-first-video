// timing.ts — সময়, সিনের জানালা (graphicWindows) ও জুম এক জায়গায়।
export const FPS = 60;
export const WIDTH = 540;
export const HEIGHT = 960;
export const DURATION = 2156; // ৩৫.৯৩৬s × ৬০
export const VIDEO_SRC = "IMG_5878.MOV";
export const f = (s: number) => Math.round(s * FPS);

// টেক্সট-বহনকারী প্রতিটি গ্রাফিক্স: [শুরু, শেষ] সেকেন্ড। ক্যাপশন এই তালিকা দেখে লুকায়।
export const S = {
  greet: [2.4, 3.7],
  third: [3.7, 5.1],
  welcome: [5.1, 6.6],
  collection: [8.0, 12.3],
  rating: [12.3, 14.3],
  spot: [14.3, 17.7],
  price: [20.8, 25.5],
  contacts: [25.5, 29.2],
  location: [29.2, 32.9],
  closing: [32.9, 35.94],
} as const;

export const graphicWindows = Object.values(S).map(([a, b]) => ({ from: f(a), to: f(b) }));

// জুম: t সেকেন্ড, s স্কেল (সর্বোচ্চ ১.০৪, ৫৪০p উৎস), x/y মূল ট্রান্সফর্ম-অরিজিন %
export const ZOOM = [
  { t: 0, s: 1.0, x: 50, y: 25 },
  { t: 2.4, s: 1.03, x: 50, y: 25 },
  { t: 3.7, s: 1.03, x: 50, y: 25 },
  { t: 4.4, s: 1.04, x: 50, y: 25 },
  { t: 5.4, s: 1.04, x: 50, y: 25 },
  { t: 6.6, s: 1.0, x: 50, y: 50 },
  { t: 8.0, s: 1.0, x: 50, y: 50 },
  { t: 11.0, s: 1.03, x: 50, y: 50 },
  { t: 12.8, s: 1.0, x: 50, y: 50 },
  { t: 14.3, s: 1.0, x: 50, y: 50 },
  { t: 15.0, s: 1.04, x: 50, y: 50 },
  { t: 16.5, s: 1.04, x: 50, y: 50 },
  { t: 17.5, s: 1.0, x: 50, y: 50 },
  { t: 25.5, s: 1.0, x: 50, y: 50 },
  { t: 27.5, s: 1.03, x: 50, y: 50 },
  { t: 28.8, s: 1.0, x: 50, y: 50 },
  { t: 29.5, s: 1.0, x: 50, y: 25 },
  { t: 32.5, s: 1.03, x: 50, y: 25 },
  { t: 34.5, s: 1.03, x: 50, y: 25 },
  { t: 35.94, s: 1.0, x: 50, y: 25 },
] as const;

export const CONTACT_NUMBERS = ["01951881563", "01913836726", "01888059757"];
