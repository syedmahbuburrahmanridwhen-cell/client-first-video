import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { CONTACT_NUMBERS, f } from "../timing";
import { Exit, Icon, Pop, Tile, WordReveal, card, clamp, plate, useExit, useUnit } from "../components/bits";

const abs = (s: React.CSSProperties): React.CSSProperties => ({ position: "absolute", ...s });
const draw = (frame: number, from: number, dur: number) =>
  interpolate(frame, [from, from + dur], [0, 1], { easing: theme.ease.out, ...clamp });

// ০.০–২.৪: কোণে bracket draw-on (লেখা নেই)
export const IntroBrackets: React.FC = () => {
  const frame = useCurrentFrame();
  const u = useUnit();
  const ex = useExit(12);
  const L = 13 * u, m = 6 * u;
  const corner = (rot: number, style: React.CSSProperties, i: number) => (
    <svg key={i} width={L} height={L} viewBox="0 0 10 10" style={abs({ ...style, transform: `rotate(${rot}deg)`, opacity: 1 - ex })}>
      <path d="M0 9V0H9" pathLength={1} fill="none" stroke={theme.colors.accent} strokeWidth={0.7} strokeLinecap="round"
        strokeDasharray={1} strokeDashoffset={1 - draw(frame, i * 4, 28)} />
    </svg>
  );
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {corner(0, { left: m, top: m * 2 }, 0)}
      {corner(90, { right: m, top: m * 2 }, 1)}
      {corner(270, { left: m, bottom: m * 2 }, 2)}
      {corner(180, { right: m, bottom: m * 2 }, 3)}
    </AbsoluteFill>
  );
};

// ২.৪–৩.৭: kinetic শুভেচ্ছা
export const Greeting: React.FC = () => {
  const u = useUnit();
  return (
    <Exit>
      <div style={abs({ left: 0, right: 0, top: "9%", display: "flex", flexDirection: "column", alignItems: "center", gap: 2 * u })}>
        <div style={{ ...plate(u), fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 9.4 * u }}>
          <WordReveal text="আসসালামু আলাইকুম" per={6} accentWords={["আসসালামু", "আলাইকুম"]} />
        </div>
        <Pop delay={14} dy={24} kind="snappy">
          <div style={{ ...plate(u), fontFamily: theme.fonts.bn, fontWeight: 500, fontSize: 6.4 * u }}>
            <WordReveal text="সম্মানিত কাস্টমারস" per={6} delay={14} />
          </div>
        </Pop>
      </div>
    </Exit>
  );
};

// lower third (৩.৭–৫.১ ও শেষে)
export const LowerThird: React.FC = () => {
  const u = useUnit();
  const frame = useCurrentFrame();
  const line = draw(frame, 14, 30);
  const breathe = 1 + Math.sin(frame / 22) * 0.006;
  return (
    <Exit>
      <Pop dy={80} kind="smooth" style={abs({ left: "6%", right: "6%", bottom: "15%" })}>
        <div style={{ ...card(u), padding: `${2.2 * u}px ${3 * u}px`, display: "flex", alignItems: "center", gap: 3 * u, transform: `scale(${breathe})` }}>
          <Tile name="hanger" size={13 * u} />
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: theme.fonts.en, fontWeight: 700, fontSize: 8.4 * u, lineHeight: 1.25 }}>সাইমা Garments</div>
            <div style={{ height: 0.9 * u, marginTop: 0.8 * u, borderRadius: u, background: theme.colors.accent, width: `${line * 100}%` }} />
          </div>
        </div>
      </Pop>
    </Exit>
  );
};

const Sparkle: React.FC<{ delay: number; style: React.CSSProperties; size: number }> = ({ delay, style, size }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.bouncy });
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={abs({ ...style, transform: `scale(${p}) rotate(${(1 - p) * 90}deg)` })}>
      <path d="M12 1c1 6 5 10 11 11-6 1-10 5-11 11-1-6-5-10-11-11 6-1 10-5 11-11z" fill={theme.colors.accent} />
    </svg>
  );
};

// ৫.১–৬.৬: "সকলকে স্বাগতম"
export const Welcome: React.FC = () => {
  const u = useUnit();
  const frame = useCurrentFrame();
  const under = draw(frame, 12, 22);
  return (
    <Exit>
      <div style={abs({ left: 0, right: 0, top: "12%", display: "flex", justifyContent: "center" })}>
        <div style={{ ...plate(u), padding: `${2 * u}px ${5 * u}px`, fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 10.4 * u, position: "relative" }}>
          <WordReveal text="সকলকে স্বাগতম" per={6} accentWords={["স্বাগতম"]} />
          <div style={{ height: 0.9 * u, borderRadius: u, background: theme.colors.accent, width: `${under * 46}%`, marginLeft: "auto", marginTop: u }} />
        </div>
      </div>
      <Sparkle delay={8} size={6 * u} style={{ left: "10%", top: "9%" }} />
      <Sparkle delay={12} size={4 * u} style={{ right: "9%", top: "8%" }} />
      <Sparkle delay={16} size={5 * u} style={{ right: "12%", top: "21%" }} />
    </Exit>
  );
};

// ৮.০–১২.৩: feature card → card stack
export const Collection: React.FC = () => {
  const u = useUnit();
  const frame = useCurrentFrame();
  const swap = f(2.1);
  const aOut = interpolate(frame, [swap - 6, swap + 8], [0, 1], { easing: theme.ease.in, ...clamp });
  const base = abs({ left: "7%", right: "7%", bottom: "14%" });
  return (
    <Exit>
      <div style={{ ...base, opacity: 1 - aOut, transform: `translateY(${-aOut * 36}px) scale(${1 - aOut * 0.06})` }}>
        <Pop dy={70}>
          <div style={{ ...card(u), padding: `${2.6 * u}px ${3.4 * u}px`, display: "flex", alignItems: "center", gap: 3 * u }}>
            <Tile name="hanger" size={13 * u} />
            <div style={{ fontFamily: theme.fonts.en, fontWeight: 700, fontSize: 8.4 * u }}>tops collection</div>
          </div>
        </Pop>
      </div>
      <Pop delay={swap} dy={60} kind="bouncy" style={base}>
        <div style={{ ...card(u), padding: `${2.6 * u}px ${3.4 * u}px` }}>
          <div style={{ fontFamily: theme.fonts.en, fontWeight: 700, fontSize: 7.8 * u, display: "flex", gap: 2 * u, alignItems: "center" }}>
            <span style={{ background: theme.colors.accent, borderRadius: u * 1.4, padding: `0 ${1.6 * u}px` }}>new</span>
            <span>tops collection</span>
          </div>
          <Pop delay={swap + 10} dy={18} kind="snappy">
            <div style={{ marginTop: 2 * u, display: "inline-flex", alignItems: "center", gap: 1.6 * u, background: theme.colors.bg,
              color: theme.colors.cream, borderRadius: 10 * u, padding: `${0.8 * u}px ${3 * u}px ${0.8 * u}px ${2 * u}px`,
              fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 6.4 * u }}>
              <Icon name="snow" size={6.6 * u} color={theme.colors.accent} />
              শীতের জন্য
            </div>
          </Pop>
        </div>
      </Pop>
    </Exit>
  );
};

// ১২.৩–১৪.৩: rating
export const Rating: React.FC = () => {
  const u = useUnit();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <Exit>
      <Pop dy={70} style={abs({ left: "8%", right: "8%", bottom: "16%" })}>
        <div style={{ ...card(u), padding: `${2.8 * u}px ${3 * u}px`, textAlign: "center" }}>
          <div style={{ display: "flex", justifyContent: "center", gap: 1.6 * u }}>
            {[0, 1, 2, 3, 4].map((i) => {
              const p = spring({ frame: frame - 6 - i * 5, fps, config: theme.spring.bouncy });
              const idle = 1 + Math.sin(frame / 18 + i) * 0.03;
              return (
                <div key={i} style={{ transform: `scale(${p * idle}) rotate(${(1 - p) * -40}deg)` }}>
                  <svg width={11 * u} height={11 * u} viewBox="0 0 24 24">
                    <path d="M12 2.6l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"
                      fill={theme.colors.accent} stroke={theme.colors.text} strokeWidth={1.2} strokeLinejoin="round" />
                  </svg>
                </div>
              );
            })}
          </div>
          <Pop delay={20} dy={16} kind="snappy">
            <div style={{ marginTop: 1.8 * u, fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 7.4 * u, lineHeight: 1.4 }}>
              খুবই <span style={{ background: theme.colors.accent, borderRadius: u, padding: `0 ${1.4 * u}px` }}>ভালো quality</span>
            </div>
          </Pop>
        </div>
      </Pop>
    </Exit>
  );
};

// ১৪.৩–১৭.৭: spotlight + callout
export const Spotlight: React.FC = () => {
  const u = useUnit();
  const frame = useCurrentFrame();
  const dim = draw(frame, 0, 18);
  const ring = draw(frame, 6, 26);
  const arrow = draw(frame, 28, 22);
  const pulse = 1 + Math.sin(frame / 12) * 0.03;
  const cx = 50, cy = 44, r = 21;
  return (
    <Exit>
      <AbsoluteFill style={{ opacity: dim, background: `radial-gradient(circle at ${cx}% ${cy}%, transparent ${r * 0.9 * u}px, rgba(26,12,7,0.55) ${r * 1.15 * u}px)` }} />
      <svg viewBox="0 0 100 177.8" preserveAspectRatio="none" style={abs({ inset: 0, width: "100%", height: "100%" })}>
        <g transform={`translate(${cx} ${cy * 1.778}) scale(${pulse})`}>
          <circle r={r} fill="none" stroke={theme.colors.accent} strokeWidth={0.9} pathLength={1}
            strokeDasharray={1} strokeDashoffset={1 - ring} transform="rotate(-90)" />
        </g>
        <path d={`M ${cx} ${cy * 1.778 + r + 1} L ${cx} 127`} pathLength={1} stroke={theme.colors.accent} strokeWidth={0.8}
          strokeLinecap="round" strokeDasharray={1} strokeDashoffset={1 - arrow} fill="none" />
        <path d={`M ${cx - 3} 124 L ${cx} 127.5 L ${cx + 3} 124`} fill="none" stroke={theme.colors.accent} strokeWidth={0.8}
          strokeLinecap="round" strokeLinejoin="round" opacity={arrow > 0.9 ? 1 : 0} />
      </svg>
      <Pop delay={36} dy={50} kind="bouncy" style={abs({ left: "10%", right: "10%", bottom: "14%" })}>
        <div style={{ ...card(u), padding: `${2.4 * u}px ${3 * u}px`, textAlign: "center", fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 7.4 * u }}>
          না ধরেন <span style={{ background: theme.colors.accent, borderRadius: u, padding: `0 ${1.4 * u}px` }}>বুঝবেন না</span>
        </div>
      </Pop>
    </Exit>
  );
};

// ২০.৮–২৫.৫: ফুল-স্ক্রিন প্রাইস সিন (Modern 2D) + কোণের ব্যাজ
export const PriceScene: React.FC = () => {
  const u = useUnit();
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const sceneEnd = f(3.1);
  const reveal = interpolate(frame, [0, f(0.5)], [0, 78], { easing: theme.ease.out, ...clamp });
  const hide = interpolate(frame, [sceneEnd - f(0.4), sceneEnd], [78, 0], { easing: theme.ease.in, ...clamp });
  const r = frame < sceneEnd - f(0.4) ? reveal : hide;
  const num = interpolate(spring({ frame: frame - 14, fps, config: { damping: 30, stiffness: 60 } }), [0, 1], [0, 50]);
  const ring = interpolate(spring({ frame: frame - 14, fps, config: { damping: 30, stiffness: 60 } }), [0, 1], [0, 1]);
  const breathe = 1 + Math.sin(frame / 20) * 0.018;
  const d1 = Math.sin(frame / 55) * 40, d2 = Math.cos(frame / 70) * 30;
  const shapes = [
    { x: 12, y: 14, s: 14, r: 50 }, { x: 82, y: 22, s: 9, r: 20 }, { x: 18, y: 78, s: 11, r: 22 },
    { x: 80, y: 74, s: 16, r: 50 }, { x: 50, y: 8, s: 7, r: 18 }, { x: 88, y: 50, s: 6, r: 50 },
  ];
  const badge = spring({ frame: frame - sceneEnd, fps, config: theme.spring.bouncy });
  const ex = useExit();
  return (
    <>
      {r > 0.5 && (
        <AbsoluteFill style={{ clipPath: `circle(${r}% at 50% 50%)`, background: `linear-gradient(160deg, ${theme.colors.bg}, ${theme.colors.bgDeep})` }}>
          <div style={abs({ width: width * 1.3, height: width * 1.3, borderRadius: "50%", top: -width * 0.4, left: -width * 0.3 + d1, filter: "blur(40px)",
            background: `radial-gradient(circle, ${theme.colors.accent}44, transparent 62%)` })} />
          <div style={abs({ width: width, height: width, borderRadius: "50%", bottom: -width * 0.4, right: -width * 0.3 - d2, filter: "blur(50px)",
            background: `radial-gradient(circle, ${theme.colors.accent}22, transparent 65%)` })} />
          {shapes.map((s, i) => (
            <div key={i} style={abs({ left: `${s.x}%`, top: `${s.y}%`, width: s.s * u, height: s.s * u, borderRadius: `${s.r}%`,
              border: `${0.5 * u}px solid ${theme.colors.cream}22`, transform: `translateY(${Math.sin(frame / 40 + i) * 10}px) rotate(${frame * (i % 2 ? 0.3 : -0.3)}deg)` })} />
          ))}
          <Pop delay={10} dy={30} kind="snappy" style={abs({ left: 0, right: 0, top: "26%", display: "flex", justifyContent: "center" })}>
            <div style={{ background: theme.colors.card, color: theme.colors.text, borderRadius: 10 * u, padding: `${1 * u}px ${5 * u}px`,
              fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 7.6 * u }}>দাম মাত্র</div>
          </Pop>
          <div style={abs({ left: 0, right: 0, top: "37%", height: 40 * u, display: "flex", alignItems: "center", justifyContent: "center" })}>
            <svg width={44 * u} height={44 * u} viewBox="0 0 100 100" style={abs({ transform: "rotate(-90deg)" })}>
              <circle cx={50} cy={50} r={46} fill="none" stroke={`${theme.colors.cream}22`} strokeWidth={2} />
              <circle cx={50} cy={50} r={46} fill="none" stroke={theme.colors.accent} strokeWidth={2.6} strokeLinecap="round"
                pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ring} />
            </svg>
            <div style={{ fontFamily: theme.fonts.en, fontWeight: 700, fontSize: 24 * u, color: theme.colors.accent, fontVariantNumeric: "tabular-nums",
              transform: `scale(${breathe})` }}>{Math.round(num)}</div>
          </div>
          <Pop delay={24} dy={30} kind="snappy" style={abs({ left: 0, right: 0, top: "66%", textAlign: "center" })}>
            <div style={{ fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 9 * u, color: theme.colors.cream }}>টাকা থেকে শুরু</div>
          </Pop>
        </AbsoluteFill>
      )}
      {frame >= sceneEnd - 2 && (
        <div style={abs({ right: "6%", top: "7%", opacity: Math.min(1, badge) * (1 - ex), transform: `scale(${0.7 + 0.3 * badge}) translateY(${ex * 10}px)`, transformOrigin: "100% 0%" })}>
          <div style={{ background: theme.colors.accent, color: theme.colors.text, borderRadius: 10 * u, padding: `${1.2 * u}px ${3.6 * u}px`,
            fontFamily: theme.fonts.en, fontWeight: 700, fontSize: 6 * u, boxShadow: `0 ${1.2 * u}px ${3 * u}px ${theme.colors.shadow}` }}>50 টাকা থেকে</div>
        </div>
      )}
    </>
  );
};

// ২৫.৫–২৯.২: নম্বর কার্ড
export const Contacts: React.FC = () => {
  const u = useUnit();
  const frame = useCurrentFrame();
  const bounce = Math.sin(frame / 8) * 0.8 * u;
  return (
    <Exit>
      <Pop dy={40} kind="snappy" style={abs({ left: "8%", right: "8%", top: "46%" })}>
        <div style={{ display: "inline-flex", alignItems: "center", gap: 1.8 * u, background: theme.colors.bg, color: theme.colors.cream,
          borderRadius: 10 * u, padding: `${1 * u}px ${3 * u}px`, fontFamily: theme.fonts.en, fontWeight: 700, fontSize: 5.6 * u }}>
          screen-এ দেওয়া number-এ
          <span style={{ transform: `translateY(${bounce}px)`, display: "flex" }}><Icon name="arrow" size={5.4 * u} color={theme.colors.accent} /></span>
        </div>
      </Pop>
      {CONTACT_NUMBERS.map((n, i) => {
        const pulse = 1 + Math.sin(frame / 10 + i) * 0.05;
        return (
          <Pop key={n} delay={12 + i * 10} dy={60} kind="bouncy" style={abs({ left: "8%", right: "8%", top: `${55 + i * 12}%` })}>
            <div style={{ ...card(u), padding: `${1.8 * u}px ${3 * u}px`, display: "flex", alignItems: "center", gap: 3 * u }}>
              <div style={{ transform: `scale(${pulse})` }}><Tile name="phone" size={9 * u} /></div>
              <div style={{ fontFamily: theme.fonts.en, fontWeight: 700, fontSize: 8 * u, letterSpacing: 0.15 * u }}>{n}</div>
            </div>
          </Pop>
        );
      })}
    </Exit>
  );
};

// ২৯.২–৩২.৯: ঠিকানা
export const Location: React.FC = () => {
  const u = useUnit();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const drop = spring({ frame: frame - 14, fps, config: theme.spring.bouncy });
  const land = interpolate(frame, [30, 60], [0, 1], clamp);
  const gridShift = (frame * 0.2) % (4 * u);
  const line = (text: string, at: number, style: React.CSSProperties) => (
    <Pop delay={at} dy={18} kind="snappy"><div style={{ fontFamily: theme.fonts.bn, fontWeight: 700, lineHeight: 1.3, ...style }}>{text}</div></Pop>
  );
  return (
    <Exit>
      <Pop dy={80} style={abs({ left: "6%", right: "6%", bottom: "13%" })}>
        <div style={{ ...card(u), padding: `${3 * u}px ${3.4 * u}px`, display: "flex", alignItems: "center", gap: 3.4 * u, overflow: "hidden", position: "relative" }}>
          <div style={abs({ inset: 0, opacity: 0.07, backgroundImage: `linear-gradient(${theme.colors.text} 1px, transparent 1px), linear-gradient(90deg, ${theme.colors.text} 1px, transparent 1px)`,
            backgroundSize: `${4 * u}px ${4 * u}px`, backgroundPosition: `${gridShift}px ${gridShift}px` })} />
          <div style={{ position: "relative", width: 17 * u, height: 17 * u, flexShrink: 0 }}>
            <div style={abs({ inset: 0, borderRadius: "50%", background: theme.colors.accent, opacity: 0.35 + land * 0.1 })} />
            <div style={abs({ left: "50%", top: "50%", width: 17 * u * land, height: 17 * u * land, borderRadius: "50%", transform: "translate(-50%,-50%)",
              border: `${0.6 * u}px solid ${theme.colors.accent}`, opacity: 1 - land })} />
            <div style={abs({ left: "50%", top: "50%", transform: `translate(-50%, ${-50 - (1 - drop) * 90}%)`, opacity: Math.min(1, drop * 2) })}>
              <Icon name="pin" size={10 * u} color={theme.colors.text} fill strokeW={1.4} />
            </div>
          </div>
          <div style={{ position: "relative", flex: 1 }}>
            {line("ভুলতা গাউছিয়া", f(1.0), { fontSize: 7.6 * u })}
            {line("City Market", f(2.4), { fontSize: 6.6 * u, fontFamily: theme.fonts.en })}
            {line("১৪ নম্বর গলি", f(2.8), { fontSize: 6.6 * u })}
          </div>
        </div>
      </Pop>
    </Exit>
  );
};

// ৩২.৯–শেষ: সমাপ্তি
export const Closing: React.FC = () => {
  const u = useUnit();
  return (
    <>
      <LowerThird />
      <Exit>
        <Pop delay={f(1.9)} dy={30} kind="bouncy" style={abs({ left: 0, right: 0, top: "12%", display: "flex", justifyContent: "center" })}>
          <div style={{ ...plate(u), padding: `${2 * u}px ${6 * u}px`, fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 12 * u, color: theme.colors.accent }}>ধন্যবাদ</div>
        </Pop>
      </Exit>
    </>
  );
};
