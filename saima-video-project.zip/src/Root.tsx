import React from "react";
import { Composition } from "remotion";
import { Main } from "./Main";
import { FPS, WIDTH, HEIGHT, DURATION } from "./timing";

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={DURATION}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
