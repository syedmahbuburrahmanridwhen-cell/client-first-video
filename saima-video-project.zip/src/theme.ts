// theme.ts — সব রং, ফন্ট, ইজিং ও spring এক জায়গায়। কোথাও hex বা ইজিং ইনলাইন নয়।
import { Easing } from "remotion";
import { loadFont as loadHind } from "@remotion/google-fonts/HindSiliguri";
import { loadFont as loadPoppins } from "@remotion/google-fonts/Poppins";

const hind = loadHind("normal", { weights: ["500", "700"], subsets: ["bengali", "latin"] });
const poppins = loadPoppins("normal", { weights: ["600", "700"], subsets: ["latin"] });

export const theme = {
  colors: {
    bg: "#3A1E15", // ব্যাকড্রপ (ব্রাউন)
    bgDeep: "#26130D",
    card: "#FFF4E3", // ক্রিম কার্ড
    text: "#2A150E", // কার্ডের টেক্সট
    accent: "#F4A300", // একমাত্র অ্যাকসেন্ট
    cream: "#FFF4E3",
    shadow: "rgba(20,8,4,0.55)",
  },
  fonts: {
    bn: `${hind.fontFamily}, sans-serif`, // বাংলা + সাধারণ লেখা
    en: `${poppins.fontFamily}, ${hind.fontFamily}, sans-serif`, // ইংরেজি ও সংখ্যা
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    zoom: Easing.bezier(0.45, 0, 0.55, 1), // জুমের নরম কার্ভ, ওভারশুট নেই
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
