import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { WORDS } from "../captions";
import { theme } from "../theme";
import { FPS, f, graphicWindows } from "../timing";
import { clamp, useUnit } from "./bits";

// পাশাপাশি জানালা (ফাঁক < ০.৫s) এক করা, যাতে ক্যাপশন ঝিলিক না দেয়
const merged = (() => {
  const w = [...graphicWindows].sort((a, b) => a.from - b.from);
  const out: { from: number; to: number }[] = [];
  for (const x of w) {
    const last = out[out.length - 1];
    if (last && x.from - last.to < FPS / 2) last.to = Math.max(last.to, x.to);
    else out.push({ ...x });
  }
  return out;
})();

// গ্রাফিক্সের আগে দ্রুত ফেড-আউট (৬ ফ্রেম), পরে ফেড-ইন (৮ ফ্রেম)
const captionOpacity = (frame: number) => {
  let o = 1;
  for (const w of merged) {
    const out = interpolate(frame, [w.from - 6, w.from], [1, 0], clamp);
    const back = interpolate(frame, [w.to, w.to + 8], [0, 1], clamp);
    if (frame >= w.from - 6 && frame < w.to + 8) o = Math.min(o, frame < w.from ? out : back);
  }
  return o;
};

// পেজ: প্রতি cue থেকে সর্বোচ্চ ৪ শব্দ
type Page = { from: number; to: number; words: { w: string; s: number }[] };
const pages: Page[] = (() => {
  const res: Page[] = [];
  const cues = Array.from(new Set(WORDS.map((x) => x.cue)));
  for (const c of cues) {
    const ws = WORDS.filter((x) => x.cue === c);
    for (let i = 0; i < ws.length; i += 4) {
      const ch = ws.slice(i, i + 4);
      res.push({ from: f(ch[0].s), to: f(ch[ch.length - 1].e) + 12, words: ch.map((x) => ({ w: x.w, s: f(x.s) })) });
    }
  }
  for (let i = 0; i < res.length - 1; i++) res[i].to = Math.min(res[i].to, res[i + 1].from);
  return res;
})();

const KEYWORDS = ["quality", "কোয়ালিটি", "50", "টাকা", "tops", "collection", "new", "শীতের", "স্বাগতম", "ভালো", "দাম", "মাত্র"];
const isKey = (w: string) => KEYWORDS.includes(w.replace(/[,।?.!]/g, ""));

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const u = useUnit();
  const o = captionOpacity(frame);
  const page = pages.find((p) => frame >= p.from && frame < p.to);
  if (!page || o <= 0.01) return null;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", opacity: o }}>
      <div style={{ position: "absolute", left: "6%", right: "6%", top: "66%", display: "flex", flexWrap: "wrap",
        justifyContent: "center", columnGap: 2.2 * u, rowGap: 0.6 * u }}>
        {page.words.map((x, i) => {
          if (frame < x.s) return null;
          const p = spring({ frame: frame - x.s, fps, config: theme.spring.snappy });
          const key = isKey(x.w);
          return (
            <span key={i} style={{
              fontFamily: theme.fonts.bn, fontSize: 7 * u, fontWeight: key ? 700 : 500,
              color: key ? theme.colors.accent : theme.colors.cream,
              textShadow: `0 ${0.5 * u}px ${2.4 * u}px ${theme.colors.shadow}, 0 0 ${0.6 * u}px ${theme.colors.bgDeep}`,
              opacity: interpolate(p, [0, 0.7], [0, 1], clamp),
              transform: `translateY(${(1 - p) * 10}px) scale(${key ? 1 + 0.06 * p : 1})`,
              display: "inline-block", lineHeight: 1.3,
            }}>{x.w}</span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
