import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

// ১ইউনিট = ফ্রেম প্রস্থের ১%। সব সাইজ এই অনুপাতে।
export const useUnit = () => useVideoConfig().width / 100;

// সিনের শেষে দ্রুত এক্সিট (0 → 1)
export const useExit = (frames = 10) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  return interpolate(frame, [durationInFrames - frames, durationInFrames - 1], [0, 1], {
    easing: theme.ease.in,
    ...clamp,
  });
};

// এক্সিট র‍্যাপার
export const Exit: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => {
  const ex = useExit();
  return (
    <div style={{ position: "absolute", inset: 0, opacity: 1 - ex, transform: `translateY(${ex * 14}px)`, ...style }}>
      {children}
    </div>
  );
};

// প্রিমিয়াম এন্ট্রি: ফেড + নড়া + স্কেল + ব্লার একসাথে
export const Pop: React.FC<{
  delay?: number;
  dy?: number;
  dx?: number;
  kind?: "snappy" | "smooth" | "bouncy";
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ delay = 0, dy = 40, dx = 0, kind = "smooth", children, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring[kind] });
  const o = interpolate(p, [0, 0.6], [0, 1], clamp);
  return (
    <div
      style={{
        opacity: o,
        transform: `translate(${dx * (1 - p)}px, ${dy * (1 - p)}px) scale(${0.94 + 0.06 * p})`,
        filter: `blur(${(1 - Math.min(p, 1)) * 5}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

// শব্দ ধরে ধরে রিভিল (প্রতি শব্দে `per` ফ্রেম)
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  accentWords?: string[];
  style?: React.CSSProperties;
}> = ({ text, delay = 0, per = 5, accentWords = [], style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", columnGap: 12, ...style }}>
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const hot = accentWords.includes(w);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: interpolate(p, [0, 0.7], [0, 1], clamp),
              transform: `translateY(${(1 - p) * 26}px) scale(${0.9 + 0.1 * p})`,
              color: hot ? theme.colors.accent : theme.colors.cream,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

// সলিড গাঢ় প্লেট (ফুটেজের ওপর লেখা পড়ার জন্য)
export const plate = (u: number): React.CSSProperties => ({
  background: theme.colors.bg,
  borderRadius: 3.4 * u,
  padding: `${1.6 * u}px ${4 * u}px`,
  boxShadow: `0 ${1.2 * u}px ${4 * u}px ${theme.colors.shadow}`,
});

// সলিড ক্রিম কার্ড
export const card = (u: number): React.CSSProperties => ({
  background: theme.colors.card,
  color: theme.colors.text,
  borderRadius: 4 * u,
  boxShadow: `0 ${1.6 * u}px ${5 * u}px ${theme.colors.shadow}`,
});

// SVG আইকন (থিমের রঙে, ইমোজি নয়)
export const Icon: React.FC<{
  name: "hanger" | "snow" | "star" | "phone" | "pin" | "arrow";
  size: number;
  color: string;
  fill?: boolean;
  strokeW?: number;
}> = ({ name, size, color, fill = false, strokeW = 1.8 }) => {
  const d: Record<string, React.ReactNode> = {
    hanger: (
      <>
        <path d="M12 6.4a2.1 2.1 0 1 1 2.1 2.1c-1.2.3-2.1 1-2.1 2.2v1" />
        <path d="M12 11.7 3.6 17.3a1.3 1.3 0 0 0 .7 2.4h15.4a1.3 1.3 0 0 0 .7-2.4z" />
      </>
    ),
    snow: (
      <>
        <path d="M12 3v18M4.2 7.5l15.6 9M4.2 16.5l15.6-9" />
        <path d="M9.6 4.6 12 6.6l2.4-2M9.6 19.4l2.4-2 2.4 2" />
      </>
    ),
    star: <path d="M12 2.6l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z" />,
    phone: (
      <path d="M6.6 3h3l1.4 4.2-2 1.4a12 12 0 0 0 5.4 5.4l1.4-2 4.2 1.4v3a2 2 0 0 1-2.2 2A16 16 0 0 1 4.6 5.2 2 2 0 0 1 6.6 3z" />
    ),
    pin: (
      <>
        <path d="M12 21s-6.5-6.2-6.5-11a6.5 6.5 0 1 1 13 0c0 4.8-6.5 11-6.5 11z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    arrow: <path d="M12 4v15M5.5 13l6.5 6.5 6.5-6.5" />,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill ? color : "none"} stroke={color}
      strokeWidth={strokeW} strokeLinecap="round" strokeLinejoin="round">
      {d[name]}
    </svg>
  );
};

// আইকন টাইল: অ্যাকসেন্ট জমিন, গাঢ় আইকন, গোলাকার কোণ
export const Tile: React.FC<{ name: Parameters<typeof Icon>[0]["name"]; size: number }> = ({ name, size }) => (
  <div style={{ width: size, height: size, borderRadius: size * 0.28, background: theme.colors.accent,
    display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
    <Icon name={name} size={size * 0.58} color={theme.colors.text} />
  </div>
);
