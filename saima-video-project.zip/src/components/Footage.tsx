import React from "react";
import { AbsoluteFill, OffthreadVideo, interpolate, staticFile, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { FPS, VIDEO_SRC, ZOOM } from "../timing";

const zoomAt = (frame: number) => {
  const t = frame / FPS;
  let i = 0;
  while (i < ZOOM.length - 2 && t >= ZOOM[i + 1].t) i++;
  const a = ZOOM[i], b = ZOOM[i + 1];
  const p = interpolate(t, [a.t, b.t], [0, 1], { easing: theme.ease.zoom, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return { s: a.s + (b.s - a.s) * p, x: a.x + (b.x - a.x) * p, y: a.y + (b.y - a.y) * p };
};

// মূল ভিডিও + নরম জুম। জুম শুধু ফুটেজে, গ্রাফিক্স স্ক্রিনের সাপেক্ষে স্থির।
export const Footage: React.FC = () => {
  const frame = useCurrentFrame();
  const z = zoomAt(frame);
  return (
    <AbsoluteFill style={{ background: theme.colors.bgDeep, overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${z.s})`, transformOrigin: `${z.x}% ${z.y}%` }}>
        <OffthreadVideo src={staticFile(VIDEO_SRC)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

// হালকা উষ্ণ গ্রেড + নরম ভিনিয়েট (গ্রাফিক্সের নিচে)
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.bg, mixBlendMode: "soft-light", opacity: 0.12 }} />
    <AbsoluteFill style={{ background: "radial-gradient(ellipse at center, transparent 60%, rgba(20,8,4,0.22) 100%)" }} />
  </AbsoluteFill>
);
